export default function AdminPanel() {
  return (
    <div>
      <h2>Admin Panel</h2>
      <p>Restricted admin functionality.</p>
    </div>
  );
}
