export default function ProfileSettings() {
  return (
    <div>
      <h3>Profile Settings</h3>
      <p>Change your preferences here.</p>
    </div>
  );
}
