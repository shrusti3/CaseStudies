export async function fetchCollaborators() {
  return [
    { id: "u1", name: "Alex" },
    { id: "u2", name: "Sam" },
  ];
}
