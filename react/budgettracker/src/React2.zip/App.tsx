import BudgetTracker from './BudgetTracker';

function App() {
  return <BudgetTracker />;
}

export default App;
